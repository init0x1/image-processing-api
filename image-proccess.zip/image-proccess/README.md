
# Scripts to Use:
---
> for running build =>  ```npm run build```
---
> for running prettier format =>  ``` npm run format```
---
> for running lint =>  ``` npm run lint```
---
> for running jasmine tests use=>  ``` npm run test```
---
> for running the server use=>   ``` npm run start```


# For Useing Api 
Example :
http://localhost:3000/api/resize?image=fjord&height=990&width=48